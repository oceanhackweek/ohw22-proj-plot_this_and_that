The following commands were used to create the files in this container:

ncks -O -h -d lat,-90.000000,-40.000000 -d lon,-180.000000,180.000000 ecoocean_gfdl-esm4_nobasd_historical_histsoc_default_tc_global_monthly_1950_2014.nc ecoocean_gfdl-esm4_nobasd_historical_histsoc_default_tc_lat-90.0to-40.0lon-180.0to180.0_monthly_1950_2014.nc
